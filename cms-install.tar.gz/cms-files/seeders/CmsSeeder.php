<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\AdminUser;
use App\Models\CmsSection;
use App\Models\CmsSetting;

class CmsSeeder extends Seeder {
    public function run(): void {

        // Admin user
        AdminUser::firstOrCreate(['email'=>'admin@holaboliviatravel.com'],[
            'nombre'   => 'Administrador',
            'password' => Hash::make('Bolivia2026!'),
            'rol'      => 'superadmin',
            'activo'   => true,
        ]);

        // Hero defaults
        $hero = [
            'eyebrow'       => 'Descubre Bolivia',
            'titulo'        => 'HOLA',
            'titulo_acento' => 'BOLIVIA',
            'subtitulo'     => 'Exploramos el corazón de Sudamérica. Tours auténticos, paisajes únicos, experiencias que transforman.',
            'btn1_texto'    => 'Ver Destinos',
            'btn1_url'      => '#destinos',
            'btn2_texto'    => 'Nuestros Tours',
            'btn2_url'      => '#tours',
        ];
        foreach ($hero as $campo => $valor) CmsSection::firstOrCreate(
            ['seccion'=>'hero','campo'=>$campo],
            ['valor'=>$valor,'tipo'=>'text']
        );

        // Nosotros defaults
        $nosotros = [
            'titulo'     => 'Apasionados por Bolivia',
            'subtitulo'  => 'Somos tu guía local',
            'texto'      => 'Con años de experiencia mostrando lo mejor de Bolivia, nuestro equipo local te lleva a descubrir paisajes únicos, culturas ancestrales y aventuras inolvidables.',
            'stat1_num'  => '500+',
            'stat1_label'=> 'Viajeros felices',
            'stat2_num'  => '25+',
            'stat2_label'=> 'Destinos',
            'stat3_num'  => '8+',
            'stat3_label'=> 'Años de experiencia',
        ];
        foreach ($nosotros as $campo => $valor) CmsSection::firstOrCreate(
            ['seccion'=>'nosotros','campo'=>$campo],
            ['valor'=>$valor,'tipo'=>'text']
        );

        // Ticker
        CmsSection::firstOrCreate(
            ['seccion'=>'ticker','campo'=>'items'],
            ['valor'=>'Salar de Uyuni|Lago Titicaca|Yungas|Amazonía Boliviana|Potosí|Sucre Colonial|Valle de la Luna|Madidi|Tiahuanaco','tipo'=>'text']
        );

        // Contacto
        $contacto = [
            'titulo'    => 'Planifica tu aventura',
            'subtitulo' => 'Estamos listos para ayudarte',
            'telefono'  => '+591 63105721',
            'whatsapp'  => '59163105721',
            'email'     => 'info@holaboliviatravel.com',
            'direccion' => 'La Paz, Bolivia',
            'instagram' => '#',
            'facebook'  => '#',
        ];
        foreach ($contacto as $campo => $valor) CmsSection::firstOrCreate(
            ['seccion'=>'contacto','campo'=>$campo],
            ['valor'=>$valor,'tipo'=>'text']
        );

        // Settings
        $settings = [
            ['key'=>'site_name',        'value'=>'Hola Bolivia Travel', 'type'=>'text',  'group'=>'general', 'label'=>'Nombre del sitio'],
            ['key'=>'site_tagline',     'value'=>'Tu agencia de turismo en Bolivia', 'type'=>'text', 'group'=>'general','label'=>'Tagline'],
            ['key'=>'color_acento',     'value'=>'oklch(68% 0.14 195)', 'type'=>'color', 'group'=>'general','label'=>'Color acento'],
            ['key'=>'meta_descripcion', 'value'=>'Hola Bolivia Travel — Tours y destinos auténticos en Bolivia.', 'type'=>'textarea','group'=>'seo','label'=>'Meta descripción'],
        ];
        foreach ($settings as $s) CmsSetting::firstOrCreate(['key'=>$s['key']], $s);
    }
}
