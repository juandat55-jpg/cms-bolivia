<?php
namespace App\Http\Controllers;
use App\Models\CmsSection;
use App\Models\CmsSetting;
use App\Models\Destino;
use App\Models\Tour;
use App\Models\Galeria;

class FrontendController extends Controller {
    public function index() {
        $hero     = CmsSection::seccion('hero');
        $nosotros = CmsSection::seccion('nosotros');
        $contacto = CmsSection::seccion('contacto');
        $ticker   = CmsSection::seccion('ticker');
        $config   = CmsSetting::grupo('general');
        $destinos = Destino::activos()->take(6)->get();
        $tours    = Tour::activos()->where('destacado',true)->take(4)->get();
        $galeria  = Galeria::activos()->seccion('galeria')->take(12)->get();
        return view('frontend.index', compact('hero','nosotros','contacto','ticker','config','destinos','tours','galeria'));
    }
}
