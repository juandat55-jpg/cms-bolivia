<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Destino;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class DestinosController extends Controller {

    public function index() {
        $destinos = Destino::orderBy('orden')->orderBy('created_at','desc')->paginate(12);
        return view('admin.destinos.index', compact('destinos'));
    }

    public function create() { return view('admin.destinos.form', ['destino'=>null]); }

    public function store(Request $request) {
        $data = $this->validar($request);
        $data = $this->handleImages($request, $data);
        $data['slug'] = Str::slug($data['nombre']);
        Destino::create($data);
        return redirect()->route('admin.destinos.index')->with('success','Destino creado ✓');
    }

    public function edit(Destino $destino) { return view('admin.destinos.form', compact('destino')); }

    public function update(Request $request, Destino $destino) {
        $data = $this->validar($request);
        $data = $this->handleImages($request, $data, $destino);
        $destino->update($data);
        return redirect()->route('admin.destinos.index')->with('success','Destino actualizado ✓');
    }

    public function destroy(Destino $destino) {
        if ($destino->imagen) Storage::disk('public')->delete($destino->imagen);
        if ($destino->imagen_banner) Storage::disk('public')->delete($destino->imagen_banner);
        $destino->delete();
        return back()->with('success','Destino eliminado ✓');
    }

    public function toggleActivo(Destino $destino) {
        $destino->update(['activo' => !$destino->activo]);
        return response()->json(['activo' => $destino->activo]);
    }

    private function validar(Request $request): array {
        return $request->validate([
            'nombre'           => 'required|string|max:200',
            'ubicacion'        => 'nullable|string|max:200',
            'descripcion_corta'=> 'nullable|string|max:500',
            'descripcion'      => 'nullable|string',
            'duracion'         => 'nullable|string|max:100',
            'precio_desde'     => 'nullable|string|max:100',
            'destacado'        => 'boolean',
            'activo'           => 'boolean',
            'orden'            => 'integer|min:0',
        ]);
    }

    private function handleImages(Request $request, array $data, ?Destino $destino = null): array {
        if ($request->hasFile('imagen')) {
            if ($destino?->imagen) Storage::disk('public')->delete($destino->imagen);
            $data['imagen'] = $request->file('imagen')->store('destinos','public');
        }
        if ($request->hasFile('imagen_banner')) {
            if ($destino?->imagen_banner) Storage::disk('public')->delete($destino->imagen_banner);
            $data['imagen_banner'] = $request->file('imagen_banner')->store('destinos','public');
        }
        return $data;
    }
}
