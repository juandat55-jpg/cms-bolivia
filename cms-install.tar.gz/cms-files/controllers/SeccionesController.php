<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\CmsSection;
use App\Models\CmsSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SeccionesController extends Controller {

    // ── HERO ──────────────────────────────────────
    public function hero() {
        $data = CmsSection::seccion('hero');
        return view('admin.secciones.hero', compact('data'));
    }

    public function heroSave(Request $request) {
        $campos = ['eyebrow','titulo','titulo_acento','subtitulo','btn1_texto','btn1_url','btn2_texto','btn2_url'];
        foreach ($campos as $campo) {
            if ($request->has($campo)) {
                CmsSection::set('hero', $campo, $request->input($campo));
            }
        }

        // Video de fondo
        if ($request->hasFile('video_fondo')) {
            $request->validate(['video_fondo' => 'file|mimetypes:video/mp4,video/webm|max:102400']);
            $old = CmsSection::get('hero','video_fondo');
            if ($old) Storage::disk('public')->delete($old);
            $path = $request->file('video_fondo')->store('cms/hero','public');
            CmsSection::set('hero','video_fondo',$path);
        }

        // Imagen fallback
        if ($request->hasFile('imagen_fondo')) {
            $request->validate(['imagen_fondo' => 'image|max:10240']);
            $old = CmsSection::get('hero','imagen_fondo');
            if ($old) Storage::disk('public')->delete($old);
            $path = $request->file('imagen_fondo')->store('cms/hero','public');
            CmsSection::set('hero','imagen_fondo',$path);
        }

        return back()->with('success','Sección Hero actualizada ✓');
    }

    // ── NOSOTROS ──────────────────────────────────
    public function nosotros() {
        $data = CmsSection::seccion('nosotros');
        return view('admin.secciones.nosotros', compact('data'));
    }

    public function nosotrosSave(Request $request) {
        $campos = ['titulo','subtitulo','texto','stat1_num','stat1_label','stat2_num','stat2_label','stat3_num','stat3_label'];
        foreach ($campos as $campo) {
            if ($request->has($campo)) CmsSection::set('nosotros', $campo, $request->input($campo));
        }
        if ($request->hasFile('imagen')) {
            $path = $request->file('imagen')->store('cms/nosotros','public');
            CmsSection::set('nosotros','imagen',$path);
        }
        return back()->with('success','Sección Nosotros actualizada ✓');
    }

    // ── TICKER ────────────────────────────────────
    public function ticker() {
        $data = CmsSection::seccion('ticker');
        return view('admin.secciones.ticker', compact('data'));
    }

    public function tickerSave(Request $request) {
        $items = array_filter($request->input('items', []));
        CmsSection::set('ticker','items', implode('|', $items));
        return back()->with('success','Ticker actualizado ✓');
    }

    // ── CONTACTO ──────────────────────────────────
    public function contacto() {
        $data = CmsSection::seccion('contacto');
        return view('admin.secciones.contacto', compact('data'));
    }

    public function contactoSave(Request $request) {
        $campos = ['titulo','subtitulo','telefono','whatsapp','email','direccion','instagram','facebook','tiktok'];
        foreach ($campos as $campo) {
            if ($request->has($campo)) CmsSection::set('contacto', $campo, $request->input($campo));
        }
        return back()->with('success','Sección Contacto actualizada ✓');
    }

    // ── CONFIG GENERAL ────────────────────────────
    public function config() {
        $data = CmsSetting::all()->keyBy('key');
        return view('admin.secciones.config', compact('data'));
    }

    public function configSave(Request $request) {
        $campos = ['site_name','site_tagline','color_acento','color_fondo','google_analytics','meta_descripcion'];
        foreach ($campos as $campo) {
            if ($request->has($campo)) CmsSetting::set($campo, $request->input($campo));
        }
        if ($request->hasFile('logo')) {
            $old = CmsSetting::get('logo');
            if ($old) Storage::disk('public')->delete($old);
            $path = $request->file('logo')->store('cms/config','public');
            CmsSetting::set('logo', $path);
        }
        return back()->with('success','Configuración guardada ✓');
    }
}
