<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Galeria;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class GaleriaController extends Controller {

    public function index(Request $request) {
        $seccion = $request->get('seccion','galeria');
        $fotos = Galeria::where('seccion',$seccion)->orderBy('orden')->orderBy('created_at','desc')->paginate(20);
        return view('admin.galeria.index', compact('fotos','seccion'));
    }

    public function upload(Request $request) {
        $request->validate([
            'archivos'   => 'required',
            'archivos.*' => 'file|mimetypes:image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm|max:51200',
            'seccion'    => 'required|string',
        ]);

        $subidos = [];
        foreach ($request->file('archivos') as $archivo) {
            $mime = $archivo->getMimeType();
            $tipo = str_starts_with($mime,'video/') ? 'video' : 'imagen';
            $path = $archivo->store('galeria','public');
            $item = Galeria::create([
                'archivo'  => $path,
                'tipo'     => $tipo,
                'seccion'  => $request->input('seccion','galeria'),
                'titulo'   => $request->input('titulo'),
                'alt'      => $request->input('alt'),
                'activo'   => true,
                'orden'    => Galeria::where('seccion',$request->input('seccion','galeria'))->max('orden') + 1,
            ]);
            $subidos[] = ['id'=>$item->id,'url'=>$item->url,'tipo'=>$tipo];
        }

        return response()->json(['success'=>true,'items'=>$subidos]);
    }

    public function update(Request $request, Galeria $galeria) {
        $galeria->update($request->only('titulo','alt','descripcion','activo','orden'));
        return response()->json(['success'=>true]);
    }

    public function destroy(Galeria $galeria) {
        Storage::disk('public')->delete($galeria->archivo);
        $galeria->delete();
        if (request()->wantsJson()) return response()->json(['success'=>true]);
        return back()->with('success','Archivo eliminado ✓');
    }

    public function reorder(Request $request) {
        foreach ($request->input('orden',[]) as $idx => $id) {
            Galeria::where('id',$id)->update(['orden'=>$idx]);
        }
        return response()->json(['success'=>true]);
    }
}
