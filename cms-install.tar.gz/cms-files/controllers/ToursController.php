<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Tour;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ToursController extends Controller {

    public function index() {
        $tours = Tour::orderBy('orden')->orderBy('created_at','desc')->paginate(12);
        return view('admin.tours.index', compact('tours'));
    }

    public function create() { return view('admin.tours.form', ['tour'=>null]); }

    public function store(Request $request) {
        $data = $this->validar($request);
        $data = $this->processArrays($request, $data);
        if ($request->hasFile('imagen')) {
            $data['imagen'] = $request->file('imagen')->store('tours','public');
        }
        $data['slug'] = Str::slug($data['nombre']);
        Tour::create($data);
        return redirect()->route('admin.tours.index')->with('success','Tour creado ✓');
    }

    public function edit(Tour $tour) { return view('admin.tours.form', compact('tour')); }

    public function update(Request $request, Tour $tour) {
        $data = $this->validar($request);
        $data = $this->processArrays($request, $data);
        if ($request->hasFile('imagen')) {
            if ($tour->imagen) Storage::disk('public')->delete($tour->imagen);
            $data['imagen'] = $request->file('imagen')->store('tours','public');
        }
        $tour->update($data);
        return redirect()->route('admin.tours.index')->with('success','Tour actualizado ✓');
    }

    public function destroy(Tour $tour) {
        if ($tour->imagen) Storage::disk('public')->delete($tour->imagen);
        $tour->delete();
        return back()->with('success','Tour eliminado ✓');
    }

    public function toggleActivo(Tour $tour) {
        $tour->update(['activo' => !$tour->activo]);
        return response()->json(['activo' => $tour->activo]);
    }

    private function validar(Request $request): array {
        return $request->validate([
            'nombre'           => 'required|string|max:200',
            'categoria'        => 'nullable|string|max:100',
            'descripcion_corta'=> 'nullable|string|max:500',
            'descripcion'      => 'nullable|string',
            'duracion'         => 'nullable|string|max:100',
            'precio_desde'     => 'nullable|string|max:100',
            'dificultad'       => 'nullable|string|max:50',
            'max_personas'     => 'nullable|integer',
            'destacado'        => 'boolean',
            'activo'           => 'boolean',
            'orden'            => 'integer|min:0',
        ]);
    }

    private function processArrays(Request $request, array $data): array {
        $incluye    = array_filter($request->input('incluye', []));
        $no_incluye = array_filter($request->input('no_incluye', []));
        $data['incluye']    = !empty($incluye) ? $incluye : null;
        $data['no_incluye'] = !empty($no_incluye) ? $no_incluye : null;
        return $data;
    }
}
