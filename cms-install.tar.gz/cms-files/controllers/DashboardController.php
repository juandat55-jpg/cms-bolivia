<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Destino;
use App\Models\Tour;
use App\Models\Galeria;

class DashboardController extends Controller {
    public function index() {
        $stats = [
            'destinos' => Destino::count(),
            'tours'    => Tour::count(),
            'fotos'    => Galeria::where('tipo','imagen')->count(),
            'videos'   => Galeria::where('tipo','video')->count(),
        ];
        return view('admin.dashboard', compact('stats'));
    }
}
