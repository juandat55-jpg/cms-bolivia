<!DOCTYPE html>
<html lang="es" class="h-full">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>@yield('title','CMS') — {{ config('app.name') }}</title>
<script src="https://cdn.tailwindcss.com"></script>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<style>
  [x-cloak]{display:none!important}
  .sidebar-link{@apply flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-all text-sm font-medium;}
  .sidebar-link.active{@apply text-white bg-white/15;}
  .form-input{@apply w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition;}
  .form-label{@apply block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5;}
  .btn-primary{@apply bg-teal-500 hover:bg-teal-400 text-white font-semibold px-5 py-2.5 rounded-lg text-sm transition-all;}
  .btn-danger{@apply bg-red-500/20 hover:bg-red-500/30 text-red-400 font-semibold px-4 py-2 rounded-lg text-sm transition-all;}
  .btn-ghost{@apply bg-white/10 hover:bg-white/20 text-white font-semibold px-4 py-2 rounded-lg text-sm transition-all;}
  .card{@apply bg-slate-800 border border-slate-700 rounded-xl p-6;}
</style>
</head>
<body class="h-full bg-slate-900 text-white" x-data="{sidebarOpen:false}">

{{-- SIDEBAR OVERLAY mobile --}}
<div x-show="sidebarOpen" x-cloak @click="sidebarOpen=false"
  class="fixed inset-0 bg-black/60 z-20 lg:hidden"></div>

{{-- SIDEBAR --}}
<aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'"
  class="fixed top-0 left-0 h-full w-64 bg-slate-900 border-r border-slate-800 z-30 transition-transform duration-200 flex flex-col">

  {{-- Logo --}}
  <div class="p-6 border-b border-slate-800">
    <div class="flex items-center gap-3">
      <div class="w-8 h-8 bg-teal-500 rounded-lg flex items-center justify-center text-slate-900 font-black text-sm">CMS</div>
      <div>
        <div class="text-sm font-bold text-white">Hola Bolivia</div>
        <div class="text-xs text-slate-500">Panel de control</div>
      </div>
    </div>
  </div>

  {{-- Nav --}}
  <nav class="flex-1 p-4 space-y-1 overflow-y-auto">

    <a href="{{ route('admin.dashboard') }}"
      class="sidebar-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7h18M3 12h18M3 17h18"/></svg>
      Dashboard
    </a>

    <div class="pt-4 pb-1 px-4 text-xs font-bold text-slate-600 uppercase tracking-widest">Contenido</div>

    <a href="{{ route('admin.destinos.index') }}"
      class="sidebar-link {{ request()->routeIs('admin.destinos*') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg>
      Destinos
    </a>

    <a href="{{ route('admin.tours.index') }}"
      class="sidebar-link {{ request()->routeIs('admin.tours*') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>
      Tours
    </a>

    <a href="{{ route('admin.galeria.index') }}"
      class="sidebar-link {{ request()->routeIs('admin.galeria*') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
      Galería
    </a>

    <div class="pt-4 pb-1 px-4 text-xs font-bold text-slate-600 uppercase tracking-widest">Secciones</div>

    <a href="{{ route('admin.secciones.hero') }}"
      class="sidebar-link {{ request()->routeIs('admin.secciones.hero*') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
      Hero / Portada
    </a>

    <a href="{{ route('admin.secciones.nosotros') }}"
      class="sidebar-link {{ request()->routeIs('admin.secciones.nosotros*') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      Nosotros
    </a>

    <a href="{{ route('admin.secciones.ticker') }}"
      class="sidebar-link {{ request()->routeIs('admin.secciones.ticker*') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"/></svg>
      Ticker / Banner
    </a>

    <a href="{{ route('admin.secciones.contacto') }}"
      class="sidebar-link {{ request()->routeIs('admin.secciones.contacto*') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
      Contacto
    </a>

    <div class="pt-4 pb-1 px-4 text-xs font-bold text-slate-600 uppercase tracking-widest">Sistema</div>

    <a href="{{ route('admin.config') }}"
      class="sidebar-link {{ request()->routeIs('admin.config*') ? 'active' : '' }}">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><circle cx="12" cy="12" r="3"/></svg>
      Configuración
    </a>

    <a href="{{ url('/') }}" target="_blank"
      class="sidebar-link">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
      Ver sitio web
    </a>
  </nav>

  {{-- User --}}
  <div class="p-4 border-t border-slate-800">
    <div class="flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-8 h-8 bg-teal-500/20 rounded-full flex items-center justify-center text-teal-400 text-xs font-bold">
          {{ strtoupper(substr(Auth::guard('admin')->user()->nombre,0,2)) }}
        </div>
        <div>
          <div class="text-sm font-medium text-white">{{ Auth::guard('admin')->user()->nombre }}</div>
          <div class="text-xs text-slate-500">{{ Auth::guard('admin')->user()->rol }}</div>
        </div>
      </div>
      <form action="{{ route('admin.logout') }}" method="POST">
        @csrf
        <button type="submit" class="text-slate-500 hover:text-red-400 transition-colors" title="Cerrar sesión">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
        </button>
      </form>
    </div>
  </div>
</aside>

{{-- MAIN --}}
<div class="lg:pl-64 min-h-screen flex flex-col">

  {{-- Top bar --}}
  <header class="bg-slate-900/80 backdrop-blur border-b border-slate-800 px-6 py-4 flex items-center gap-4 sticky top-0 z-10">
    <button @click="sidebarOpen=!sidebarOpen" class="lg:hidden text-slate-400 hover:text-white">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
    </button>
    <div class="flex-1">
      <h1 class="text-lg font-bold text-white">@yield('title','Dashboard')</h1>
      @hasSection('breadcrumb')
        <div class="text-xs text-slate-500 mt-0.5">@yield('breadcrumb')</div>
      @endif
    </div>
    <div class="flex items-center gap-3">
      @yield('header-actions')
    </div>
  </header>

  {{-- Alerts --}}
  @if(session('success'))
    <div class="mx-6 mt-4 bg-teal-500/20 border border-teal-500/30 text-teal-300 rounded-lg px-4 py-3 text-sm flex items-center gap-2" x-data x-init="setTimeout(()=>$el.remove(),4000)">
      <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
      {{ session('success') }}
    </div>
  @endif
  @if(session('error'))
    <div class="mx-6 mt-4 bg-red-500/20 border border-red-500/30 text-red-300 rounded-lg px-4 py-3 text-sm">
      {{ session('error') }}
    </div>
  @endif

  {{-- Content --}}
  <main class="flex-1 p-6">
    @yield('content')
  </main>
</div>

</body>
</html>
