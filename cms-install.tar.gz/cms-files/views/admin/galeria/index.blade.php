@extends('layouts.admin')
@section('title','Galería')
@section('breadcrumb','Contenido → Galería')

@section('header-actions')
<div class="flex gap-2">
  @foreach(['galeria'=>'Galería','hero'=>'Hero','destinos'=>'Destinos'] as $key => $label)
    <a href="{{ route('admin.galeria.index',['seccion'=>$key]) }}"
      class="{{ $seccion===$key ? 'bg-teal-500 text-slate-900' : 'bg-slate-700 text-slate-300 hover:bg-slate-600' }} px-3 py-1.5 rounded-lg text-xs font-semibold transition">
      {{ $label }}
    </a>
  @endforeach
</div>
@endsection

@section('content')
<div x-data="galeriaApp()" class="space-y-6">

  {{-- Upload Zone --}}
  <div class="card"
    @dragover.prevent="dragging=true"
    @dragleave="dragging=false"
    @drop.prevent="handleDrop($event)">
    <div :class="dragging ? 'border-teal-500 bg-teal-500/10' : 'border-slate-600'"
      class="border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer"
      @click="$refs.fileInput.click()">
      <svg class="w-10 h-10 text-slate-500 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/>
      </svg>
      <p class="text-sm font-medium text-slate-300">Arrastra fotos/videos aquí o haz clic para seleccionar</p>
      <p class="text-xs text-slate-500 mt-1">JPG, PNG, WebP, MP4, WebM — máx 50MB por archivo</p>
      <input type="file" x-ref="fileInput" multiple accept="image/*,video/mp4,video/webm"
        class="hidden" @change="handleFiles($event.target.files)">
    </div>

    {{-- Upload progress --}}
    <template x-if="uploading">
      <div class="mt-4 space-y-2">
        <template x-for="f in uploadQueue" :key="f.name">
          <div class="flex items-center gap-3 bg-slate-700/50 rounded-lg px-4 py-2">
            <div class="flex-1">
              <div class="text-xs text-slate-300 mb-1" x-text="f.name"></div>
              <div class="w-full bg-slate-700 rounded-full h-1.5">
                <div class="bg-teal-500 h-1.5 rounded-full transition-all" :style="`width:${f.progress}%`"></div>
              </div>
            </div>
            <span class="text-xs text-slate-400" x-text="f.progress+'%'"></span>
          </div>
        </template>
      </div>
    </template>
  </div>

  {{-- Grid de fotos --}}
  <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
    @forelse($fotos as $foto)
    <div class="relative group bg-slate-800 rounded-xl overflow-hidden aspect-square"
      x-data="{confirmDelete:false}">

      @if($foto->tipo === 'video')
        <video src="{{ $foto->url }}" class="w-full h-full object-cover"></video>
        <div class="absolute top-2 left-2 bg-black/60 rounded-md px-1.5 py-0.5 text-xs text-white flex items-center gap-1">
          <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg> video
        </div>
      @else
        <img src="{{ $foto->url }}" alt="{{ $foto->alt ?? $foto->titulo }}"
          class="w-full h-full object-cover transition group-hover:scale-105">
      @endif

      {{-- Overlay acciones --}}
      <div class="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2">
        <button type="button" @click="confirmDelete=true"
          class="w-8 h-8 bg-red-500/80 hover:bg-red-500 rounded-lg flex items-center justify-center transition">
          <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
        </button>
      </div>

      {{-- Confirm delete --}}
      <div x-show="confirmDelete" x-cloak
        class="absolute inset-0 bg-slate-900/95 flex flex-col items-center justify-center gap-2 p-3">
        <p class="text-xs text-white text-center">¿Eliminar?</p>
        <div class="flex gap-2">
          <form method="POST" action="{{ route('admin.galeria.destroy',$foto) }}">
            @csrf @method('DELETE')
            <button type="submit" class="px-3 py-1 bg-red-500 text-white text-xs rounded-lg font-semibold">Sí</button>
          </form>
          <button @click="confirmDelete=false" class="px-3 py-1 bg-slate-600 text-white text-xs rounded-lg font-semibold">No</button>
        </div>
      </div>
    </div>
    @empty
    <div class="col-span-full text-center py-16 text-slate-500">
      <svg class="w-12 h-12 mx-auto mb-3 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
      <p class="text-sm">No hay archivos en esta sección todavía</p>
    </div>
    @endforelse
  </div>

  {{-- Paginación --}}
  {{ $fotos->withQueryString()->links() }}

</div>

<script>
function galeriaApp() {
  return {
    dragging: false,
    uploading: false,
    uploadQueue: [],
    seccion: '{{ $seccion }}',

    handleDrop(e) {
      this.dragging = false;
      this.handleFiles(e.dataTransfer.files);
    },

    async handleFiles(files) {
      if (!files.length) return;
      this.uploading = true;

      const formData = new FormData();
      formData.append('seccion', this.seccion);
      formData.append('_token', document.querySelector('meta[name=csrf-token]').content);

      this.uploadQueue = [];
      for (const file of files) {
        this.uploadQueue.push({name: file.name, progress: 0});
        formData.append('archivos[]', file);
      }

      try {
        const res = await fetch('{{ route("admin.galeria.upload") }}', {
          method: 'POST',
          body: formData,
        });
        const data = await res.json();
        if (data.success) {
          window.location.reload();
        }
      } catch(e) {
        alert('Error al subir archivos');
      }
      this.uploading = false;
    }
  }
}
</script>
@endsection
