@extends('layouts.admin')
@section('title', $tour ? 'Editar: '.$tour->nombre : 'Nuevo tour')
@section('breadcrumb','Tours → '.($tour ? 'Editar' : 'Nuevo'))

@section('content')
<div class="max-w-3xl">
  <form method="POST"
    action="{{ $tour ? route('admin.tours.update',$tour) : route('admin.tours.store') }}"
    enctype="multipart/form-data" class="space-y-6"
    x-data="{incluye:{{ json_encode($tour?->incluye ?? ['']) }},noIncluye:{{ json_encode($tour?->no_incluye ?? ['']) }}}">
    @csrf
    @if($tour) @method('PUT') @endif

    <div class="card space-y-5">
      <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Información básica</h2>

      <div><label class="form-label">Nombre del tour *</label>
        <input type="text" name="nombre" value="{{ old('nombre',$tour?->nombre) }}" required class="form-input"></div>

      <div class="grid grid-cols-3 gap-4">
        <div><label class="form-label">Categoría</label>
          <select name="categoria" class="form-input">
            <option value="">— Seleccionar —</option>
            @foreach(['Aventura','Cultural','Naturaleza','Gastronómico','Fotografía','Trekking'] as $cat)
              <option value="{{ $cat }}" {{ old('categoria',$tour?->categoria)===$cat ? 'selected' : '' }}>{{ $cat }}</option>
            @endforeach
          </select></div>
        <div><label class="form-label">Dificultad</label>
          <select name="dificultad" class="form-input">
            <option value="">— —</option>
            @foreach(['Fácil','Moderado','Difícil','Extremo'] as $d)
              <option value="{{ $d }}" {{ old('dificultad',$tour?->dificultad)===$d ? 'selected' : '' }}>{{ $d }}</option>
            @endforeach
          </select></div>
        <div><label class="form-label">Máx. personas</label>
          <input type="number" name="max_personas" value="{{ old('max_personas',$tour?->max_personas) }}" min="1" class="form-input"></div>
      </div>

      <div class="grid grid-cols-2 gap-4">
        <div><label class="form-label">Duración</label>
          <input type="text" name="duracion" value="{{ old('duracion',$tour?->duracion) }}" class="form-input" placeholder="Ej: 2 días"></div>
        <div><label class="form-label">Precio desde</label>
          <input type="text" name="precio_desde" value="{{ old('precio_desde',$tour?->precio_desde) }}" class="form-input" placeholder="Ej: $150 USD"></div>
      </div>

      <div><label class="form-label">Descripción corta</label>
        <textarea name="descripcion_corta" rows="2" class="form-input">{{ old('descripcion_corta',$tour?->descripcion_corta) }}</textarea></div>

      <div><label class="form-label">Descripción completa</label>
        <textarea name="descripcion" rows="6" class="form-input">{{ old('descripcion',$tour?->descripcion) }}</textarea></div>
    </div>

    {{-- Imagen --}}
    <div class="card space-y-4">
      <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Imagen</h2>
      @if($tour?->imagen)
        <div class="rounded-lg overflow-hidden h-32 bg-slate-700"><img src="{{ asset('storage/'.$tour->imagen) }}" class="w-full h-full object-cover"></div>
      @endif
      <input type="file" name="imagen" accept="image/*"
        class="w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-teal-500/20 file:text-teal-300 hover:file:bg-teal-500/30 cursor-pointer">
    </div>

    {{-- Incluye / No incluye --}}
    <div class="card space-y-4">
      <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Incluye / No incluye</h2>
      <div class="grid grid-cols-2 gap-6">
        <div>
          <label class="form-label text-teal-400">✓ Incluye</label>
          <template x-for="(item,i) in incluye" :key="i">
            <div class="flex gap-2 mb-2">
              <input type="text" :name="`incluye[]`" x-model="incluye[i]" class="form-input flex-1" placeholder="Ej: Guía bilingüe">
              <button type="button" @click="incluye.splice(i,1)" class="text-slate-500 hover:text-red-400">✕</button>
            </div>
          </template>
          <button type="button" @click="incluye.push('')" class="text-xs text-teal-400 hover:text-teal-300">+ Agregar</button>
        </div>
        <div>
          <label class="form-label text-red-400">✗ No incluye</label>
          <template x-for="(item,i) in noIncluye" :key="i">
            <div class="flex gap-2 mb-2">
              <input type="text" :name="`no_incluye[]`" x-model="noIncluye[i]" class="form-input flex-1" placeholder="Ej: Vuelos">
              <button type="button" @click="noIncluye.splice(i,1)" class="text-slate-500 hover:text-red-400">✕</button>
            </div>
          </template>
          <button type="button" @click="noIncluye.push('')" class="text-xs text-teal-400 hover:text-teal-300">+ Agregar</button>
        </div>
      </div>
    </div>

    {{-- Opciones --}}
    <div class="card">
      <h2 class="text-sm font-bold text-white flex items-center gap-2 mb-4"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Opciones</h2>
      <div class="flex gap-6 flex-wrap">
        <label class="flex items-center gap-2 cursor-pointer">
          <input type="hidden" name="activo" value="0">
          <input type="checkbox" name="activo" value="1" {{ old('activo',$tour?->activo ?? true) ? 'checked':'' }} class="rounded border-slate-600 bg-slate-900 text-teal-500 w-4 h-4">
          <span class="text-sm text-slate-300">Activo</span>
        </label>
        <label class="flex items-center gap-2 cursor-pointer">
          <input type="hidden" name="destacado" value="0">
          <input type="checkbox" name="destacado" value="1" {{ old('destacado',$tour?->destacado) ? 'checked':'' }} class="rounded border-slate-600 bg-slate-900 text-teal-500 w-4 h-4">
          <span class="text-sm text-slate-300">Destacado</span>
        </label>
        <div class="flex items-center gap-2">
          <label class="text-sm text-slate-400">Orden:</label>
          <input type="number" name="orden" value="{{ old('orden',$tour?->orden ?? 0) }}" min="0" class="w-20 bg-slate-700 border border-slate-600 text-white rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-teal-500">
        </div>
      </div>
    </div>

    <div class="flex items-center gap-3">
      <button type="submit" class="btn-primary">{{ $tour ? 'Guardar cambios →' : 'Crear tour →' }}</button>
      <a href="{{ route('admin.tours.index') }}" class="btn-ghost">Cancelar</a>
    </div>
  </form>
</div>
@endsection
