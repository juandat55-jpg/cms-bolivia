{{-- ESTE ARCHIVO ES tours/index.blade.php --}}
@extends('layouts.admin')
@section('title','Tours')
@section('breadcrumb','Contenido → Tours')
@section('header-actions')
<a href="{{ route('admin.tours.create') }}" class="btn-primary">+ Nuevo tour</a>
@endsection
@section('content')
<div class="space-y-4">
  @forelse($tours as $tour)
  <div class="bg-slate-800 border border-slate-700 rounded-xl p-5 flex items-center gap-5 hover:border-slate-600 transition">
    <div class="w-20 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-slate-700">
      @if($tour->imagen)
        <img src="{{ asset('storage/'.$tour->imagen) }}" class="w-full h-full object-cover">
      @else
        <div class="w-full h-full flex items-center justify-center text-slate-600">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        </div>
      @endif
    </div>
    <div class="flex-1 min-w-0">
      <div class="flex items-center gap-2 mb-1">
        <h3 class="text-sm font-bold text-white truncate">{{ $tour->nombre }}</h3>
        @if($tour->categoria)<span class="bg-blue-500/20 text-blue-400 text-xs px-2 py-0.5 rounded-full">{{ $tour->categoria }}</span>@endif
        @if($tour->destacado)<span class="bg-amber-500/20 text-amber-400 text-xs px-2 py-0.5 rounded-full">Destacado</span>@endif
        <span class="{{ $tour->activo ? 'bg-teal-500/20 text-teal-400' : 'bg-slate-600/50 text-slate-400' }} text-xs px-2 py-0.5 rounded-full">
          {{ $tour->activo ? 'Activo' : 'Inactivo' }}
        </span>
      </div>
      <div class="text-xs text-slate-500 flex items-center gap-3">
        @if($tour->duracion)<span>⏱ {{ $tour->duracion }}</span>@endif
        @if($tour->precio_desde)<span>💰 Desde {{ $tour->precio_desde }}</span>@endif
        @if($tour->dificultad)<span>🏃 {{ $tour->dificultad }}</span>@endif
      </div>
    </div>
    <div class="flex items-center gap-2 flex-shrink-0">
      <a href="{{ route('admin.tours.edit',$tour) }}" class="w-8 h-8 bg-slate-700 hover:bg-slate-600 rounded-lg flex items-center justify-center transition">
        <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
      </a>
      <form method="POST" action="{{ route('admin.tours.destroy',$tour) }}" onsubmit="return confirm('¿Eliminar {{ $tour->nombre }}?')">
        @csrf @method('DELETE')
        <button type="submit" class="w-8 h-8 bg-red-500/20 hover:bg-red-500/30 rounded-lg flex items-center justify-center transition">
          <svg class="w-4 h-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
        </button>
      </form>
    </div>
  </div>
  @empty
  <div class="card text-center py-16 text-slate-500">
    <p class="text-sm mb-4">No hay tours creados todavía</p>
    <a href="{{ route('admin.tours.create') }}" class="btn-primary">Crear primer tour →</a>
  </div>
  @endforelse
  {{ $tours->links() }}
</div>
@endsection
