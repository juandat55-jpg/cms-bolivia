@extends('layouts.admin')
@section('title','Dashboard')

@section('content')
<div class="space-y-6">

  {{-- Stats --}}
  <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
    @foreach([
      ['label'=>'Destinos','value'=>$stats['destinos'],'icon'=>'M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z','color'=>'teal','route'=>'admin.destinos.index'],
      ['label'=>'Tours','value'=>$stats['tours'],'icon'=>'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7','color'=>'blue','route'=>'admin.tours.index'],
      ['label'=>'Fotos','value'=>$stats['fotos'],'icon'=>'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z','color'=>'violet','route'=>'admin.galeria.index'],
      ['label'=>'Videos','value'=>$stats['videos'],'icon'=>'M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z','color'=>'amber','route'=>'admin.galeria.index'],
    ] as $stat)
    <a href="{{ route($stat['route']) }}"
      class="bg-slate-800 border border-slate-700 rounded-xl p-5 hover:border-slate-600 transition group">
      <div class="flex items-center justify-between mb-3">
        <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider">{{ $stat['label'] }}</span>
        <div class="w-8 h-8 rounded-lg bg-{{ $stat['color'] }}-500/20 flex items-center justify-center">
          <svg class="w-4 h-4 text-{{ $stat['color'] }}-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="{{ $stat['icon'] }}"/>
          </svg>
        </div>
      </div>
      <div class="text-3xl font-black text-white">{{ $stat['value'] }}</div>
    </a>
    @endforeach
  </div>

  {{-- Accesos rápidos --}}
  <div class="card">
    <h2 class="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Acciones rápidas</h2>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
      @foreach([
        ['label'=>'Nuevo destino','route'=>'admin.destinos.create','icon'=>'M12 4v16m8-8H4'],
        ['label'=>'Nuevo tour','route'=>'admin.tours.create','icon'=>'M12 4v16m8-8H4'],
        ['label'=>'Subir fotos','route'=>'admin.galeria.index','icon'=>'M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12'],
        ['label'=>'Editar Hero','route'=>'admin.secciones.hero','icon'=>'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z'],
      ] as $a)
      <a href="{{ route($a['route']) }}"
        class="flex items-center gap-3 p-4 bg-slate-700/50 hover:bg-slate-700 rounded-xl transition group">
        <svg class="w-5 h-5 text-teal-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="{{ $a['icon'] }}"/>
        </svg>
        <span class="text-sm font-medium text-white">{{ $a['label'] }}</span>
      </a>
      @endforeach
    </div>
  </div>

  {{-- Secciones del sitio --}}
  <div class="card">
    <h2 class="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Secciones del sitio</h2>
    <div class="divide-y divide-slate-700">
      @foreach([
        ['label'=>'Hero / Portada','desc'=>'Video de fondo, título principal, botones de acción','route'=>'admin.secciones.hero'],
        ['label'=>'Ticker de destinos','desc'=>'Texto marquee que aparece debajo del hero','route'=>'admin.secciones.ticker'],
        ['label'=>'Nosotros','desc'=>'Descripción de la empresa, estadísticas','route'=>'admin.secciones.nosotros'],
        ['label'=>'Contacto','desc'=>'Teléfono, WhatsApp, email, redes sociales','route'=>'admin.secciones.contacto'],
        ['label'=>'Configuración general','desc'=>'Logo, nombre del sitio, colores','route'=>'admin.config'],
      ] as $s)
      <a href="{{ route($s['route']) }}"
        class="flex items-center justify-between py-4 hover:text-teal-400 transition group">
        <div>
          <div class="text-sm font-semibold text-white group-hover:text-teal-400 transition">{{ $s['label'] }}</div>
          <div class="text-xs text-slate-500 mt-0.5">{{ $s['desc'] }}</div>
        </div>
        <svg class="w-4 h-4 text-slate-600 group-hover:text-teal-400 transition flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
      </a>
      @endforeach
    </div>
  </div>

</div>
@endsection
