@extends('layouts.admin')
@section('title', $destino ? 'Editar: '.$destino->nombre : 'Nuevo destino')
@section('breadcrumb','Destinos → '.($destino ? 'Editar' : 'Nuevo'))

@section('content')
<div class="max-w-3xl">
  <form method="POST"
    action="{{ $destino ? route('admin.destinos.update',$destino) : route('admin.destinos.store') }}"
    enctype="multipart/form-data" class="space-y-6">
    @csrf
    @if($destino) @method('PUT') @endif

    <div class="card space-y-5">
      <h2 class="text-sm font-bold text-white flex items-center gap-2">
        <span class="w-1 h-4 bg-teal-500 rounded-full inline-block"></span>
        Información básica
      </h2>

      <div>
        <label class="form-label">Nombre del destino *</label>
        <input type="text" name="nombre" value="{{ old('nombre',$destino?->nombre) }}" required class="form-input">
        @error('nombre')<p class="text-xs text-red-400 mt-1">{{ $message }}</p>@enderror
      </div>

      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="form-label">Ubicación</label>
          <input type="text" name="ubicacion" value="{{ old('ubicacion',$destino?->ubicacion) }}" class="form-input" placeholder="Ej: Potosí, Bolivia">
        </div>
        <div>
          <label class="form-label">Duración</label>
          <input type="text" name="duracion" value="{{ old('duracion',$destino?->duracion) }}" class="form-input" placeholder="Ej: 3 días / 2 noches">
        </div>
      </div>

      <div>
        <label class="form-label">Precio desde</label>
        <input type="text" name="precio_desde" value="{{ old('precio_desde',$destino?->precio_desde) }}" class="form-input" placeholder="Ej: $299 USD">
      </div>

      <div>
        <label class="form-label">Descripción corta (para tarjeta)</label>
        <textarea name="descripcion_corta" rows="2" class="form-input" placeholder="Máximo 500 caracteres">{{ old('descripcion_corta',$destino?->descripcion_corta) }}</textarea>
      </div>

      <div>
        <label class="form-label">Descripción completa</label>
        <textarea name="descripcion" rows="6" class="form-input">{{ old('descripcion',$destino?->descripcion) }}</textarea>
      </div>
    </div>

    {{-- Imágenes --}}
    <div class="card space-y-5">
      <h2 class="text-sm font-bold text-white flex items-center gap-2">
        <span class="w-1 h-4 bg-teal-500 rounded-full inline-block"></span>
        Imágenes
      </h2>

      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="form-label">Imagen de tarjeta</label>
          @if($destino?->imagen)
            <div class="mb-2 rounded-lg overflow-hidden h-24 bg-slate-700">
              <img src="{{ asset('storage/'.$destino->imagen) }}" class="w-full h-full object-cover">
            </div>
          @endif
          <input type="file" name="imagen" accept="image/*"
            class="w-full text-sm text-slate-400 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-teal-500/20 file:text-teal-300 hover:file:bg-teal-500/30 cursor-pointer">
        </div>
        <div>
          <label class="form-label">Imagen banner (página detalle)</label>
          @if($destino?->imagen_banner)
            <div class="mb-2 rounded-lg overflow-hidden h-24 bg-slate-700">
              <img src="{{ asset('storage/'.$destino->imagen_banner) }}" class="w-full h-full object-cover">
            </div>
          @endif
          <input type="file" name="imagen_banner" accept="image/*"
            class="w-full text-sm text-slate-400 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-teal-500/20 file:text-teal-300 hover:file:bg-teal-500/30 cursor-pointer">
        </div>
      </div>
    </div>

    {{-- Opciones --}}
    <div class="card">
      <h2 class="text-sm font-bold text-white flex items-center gap-2 mb-4">
        <span class="w-1 h-4 bg-teal-500 rounded-full inline-block"></span>
        Opciones
      </h2>
      <div class="flex gap-6">
        <label class="flex items-center gap-2 cursor-pointer">
          <input type="hidden" name="activo" value="0">
          <input type="checkbox" name="activo" value="1" {{ old('activo',$destino?->activo ?? true) ? 'checked' : '' }}
            class="rounded border-slate-600 bg-slate-900 text-teal-500 w-4 h-4">
          <span class="text-sm text-slate-300">Activo (visible en el sitio)</span>
        </label>
        <label class="flex items-center gap-2 cursor-pointer">
          <input type="hidden" name="destacado" value="0">
          <input type="checkbox" name="destacado" value="1" {{ old('destacado',$destino?->destacado) ? 'checked' : '' }}
            class="rounded border-slate-600 bg-slate-900 text-teal-500 w-4 h-4">
          <span class="text-sm text-slate-300">Destacado</span>
        </label>
        <div class="flex items-center gap-2">
          <label class="text-sm text-slate-400">Orden:</label>
          <input type="number" name="orden" value="{{ old('orden',$destino?->orden ?? 0) }}" min="0"
            class="w-20 bg-slate-700 border border-slate-600 text-white rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-teal-500">
        </div>
      </div>
    </div>

    <div class="flex items-center gap-3">
      <button type="submit" class="btn-primary">
        {{ $destino ? 'Guardar cambios →' : 'Crear destino →' }}
      </button>
      <a href="{{ route('admin.destinos.index') }}" class="btn-ghost">Cancelar</a>
    </div>
  </form>
</div>
@endsection
