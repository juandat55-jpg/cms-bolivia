@extends('layouts.admin')
@section('title','Destinos')
@section('breadcrumb','Contenido → Destinos')

@section('header-actions')
<a href="{{ route('admin.destinos.create') }}" class="btn-primary">+ Nuevo destino</a>
@endsection

@section('content')
<div class="space-y-4">
  @forelse($destinos as $destino)
  <div class="bg-slate-800 border border-slate-700 rounded-xl p-5 flex items-center gap-5 hover:border-slate-600 transition">
    {{-- Imagen --}}
    <div class="w-20 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-slate-700">
      @if($destino->imagen)
        <img src="{{ asset('storage/'.$destino->imagen) }}" class="w-full h-full object-cover">
      @else
        <div class="w-full h-full flex items-center justify-center text-slate-600">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        </div>
      @endif
    </div>

    {{-- Info --}}
    <div class="flex-1 min-w-0">
      <div class="flex items-center gap-2 mb-1">
        <h3 class="text-sm font-bold text-white truncate">{{ $destino->nombre }}</h3>
        @if($destino->destacado)
          <span class="bg-amber-500/20 text-amber-400 text-xs px-2 py-0.5 rounded-full font-semibold">Destacado</span>
        @endif
        <span class="{{ $destino->activo ? 'bg-teal-500/20 text-teal-400' : 'bg-slate-600/50 text-slate-400' }} text-xs px-2 py-0.5 rounded-full font-semibold">
          {{ $destino->activo ? 'Activo' : 'Inactivo' }}
        </span>
      </div>
      <div class="text-xs text-slate-500 flex items-center gap-3">
        @if($destino->ubicacion)<span>📍 {{ $destino->ubicacion }}</span>@endif
        @if($destino->duracion)<span>⏱ {{ $destino->duracion }}</span>@endif
        @if($destino->precio_desde)<span>💰 Desde {{ $destino->precio_desde }}</span>@endif
      </div>
    </div>

    {{-- Acciones --}}
    <div class="flex items-center gap-2 flex-shrink-0">
      <a href="{{ route('admin.destinos.edit',$destino) }}"
        class="w-8 h-8 bg-slate-700 hover:bg-slate-600 rounded-lg flex items-center justify-center transition" title="Editar">
        <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
      </a>
      <form method="POST" action="{{ route('admin.destinos.destroy',$destino) }}"
        onsubmit="return confirm('¿Eliminar {{ $destino->nombre }}?')">
        @csrf @method('DELETE')
        <button type="submit"
          class="w-8 h-8 bg-red-500/20 hover:bg-red-500/30 rounded-lg flex items-center justify-center transition" title="Eliminar">
          <svg class="w-4 h-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
        </button>
      </form>
    </div>
  </div>
  @empty
  <div class="card text-center py-16 text-slate-500">
    <p class="text-sm mb-4">No hay destinos creados todavía</p>
    <a href="{{ route('admin.destinos.create') }}" class="btn-primary">Crear primer destino →</a>
  </div>
  @endforelse

  {{ $destinos->links() }}
</div>
@endsection
