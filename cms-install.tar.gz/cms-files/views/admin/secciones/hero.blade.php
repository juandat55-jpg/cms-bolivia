@extends('layouts.admin')
@section('title','Hero / Portada')
@section('breadcrumb','Secciones → Hero')

@section('content')
<div class="max-w-3xl space-y-6">

  <form method="POST" action="{{ route('admin.secciones.hero.save') }}" enctype="multipart/form-data" class="space-y-6">
    @csrf

    {{-- Media de fondo --}}
    <div class="card space-y-5">
      <h2 class="text-sm font-bold text-white flex items-center gap-2">
        <span class="w-1 h-4 bg-teal-500 rounded-full inline-block"></span>
        Fondo del Hero
      </h2>

      <div x-data="{tab:'video'}" class="space-y-4">
        <div class="flex gap-2">
          <button type="button" @click="tab='video'"
            :class="tab==='video' ? 'bg-teal-500 text-slate-900' : 'bg-slate-700 text-slate-300'"
            class="px-4 py-2 rounded-lg text-sm font-semibold transition">Video</button>
          <button type="button" @click="tab='imagen'"
            :class="tab==='imagen' ? 'bg-teal-500 text-slate-900' : 'bg-slate-700 text-slate-300'"
            class="px-4 py-2 rounded-lg text-sm font-semibold transition">Imagen</button>
        </div>

        <div x-show="tab==='video'">
          <label class="form-label">Video de fondo (MP4/WebM, máx 100MB)</label>
          @if(!empty($data['video_fondo']))
            <div class="mb-3 p-3 bg-teal-500/10 border border-teal-500/20 rounded-lg flex items-center gap-3">
              <svg class="w-4 h-4 text-teal-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
              <span class="text-xs text-teal-300 truncate">{{ basename($data['video_fondo']) }}</span>
              <span class="ml-auto text-xs text-slate-500">Video actual</span>
            </div>
          @endif
          <input type="file" name="video_fondo" accept="video/mp4,video/webm"
            class="w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-teal-500/20 file:text-teal-300 hover:file:bg-teal-500/30 cursor-pointer">
          <p class="text-xs text-slate-500 mt-1">Sube el video de fondo para la sección hero. Se recomienda MP4 comprimido.</p>
        </div>

        <div x-show="tab==='imagen'">
          <label class="form-label">Imagen de fondo (fallback)</label>
          @if(!empty($data['imagen_fondo']))
            <div class="mb-3 rounded-lg overflow-hidden h-32 bg-slate-700">
              <img src="{{ asset('storage/'.$data['imagen_fondo']) }}" class="w-full h-full object-cover">
            </div>
          @endif
          <input type="file" name="imagen_fondo" accept="image/*"
            class="w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-teal-500/20 file:text-teal-300 hover:file:bg-teal-500/30 cursor-pointer">
        </div>
      </div>
    </div>

    {{-- Textos --}}
    <div class="card space-y-5">
      <h2 class="text-sm font-bold text-white flex items-center gap-2">
        <span class="w-1 h-4 bg-teal-500 rounded-full inline-block"></span>
        Textos del Hero
      </h2>

      <div>
        <label class="form-label">Eyebrow (texto pequeño encima del título)</label>
        <input type="text" name="eyebrow" value="{{ $data['eyebrow'] ?? 'Descubre Bolivia' }}" class="form-input">
      </div>

      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="form-label">Título principal</label>
          <input type="text" name="titulo" value="{{ $data['titulo'] ?? 'HOLA' }}" class="form-input">
        </div>
        <div>
          <label class="form-label">Título acento (color dorado)</label>
          <input type="text" name="titulo_acento" value="{{ $data['titulo_acento'] ?? 'BOLIVIA' }}" class="form-input">
        </div>
      </div>

      <div>
        <label class="form-label">Subtítulo / descripción</label>
        <textarea name="subtitulo" rows="3" class="form-input">{{ $data['subtitulo'] ?? '' }}</textarea>
      </div>
    </div>

    {{-- Botones --}}
    <div class="card space-y-5">
      <h2 class="text-sm font-bold text-white flex items-center gap-2">
        <span class="w-1 h-4 bg-teal-500 rounded-full inline-block"></span>
        Botones de acción
      </h2>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="form-label">Botón 1 — Texto</label>
          <input type="text" name="btn1_texto" value="{{ $data['btn1_texto'] ?? 'Ver Destinos' }}" class="form-input">
        </div>
        <div>
          <label class="form-label">Botón 1 — URL</label>
          <input type="text" name="btn1_url" value="{{ $data['btn1_url'] ?? '#destinos' }}" class="form-input">
        </div>
        <div>
          <label class="form-label">Botón 2 — Texto</label>
          <input type="text" name="btn2_texto" value="{{ $data['btn2_texto'] ?? 'Nuestros Tours' }}" class="form-input">
        </div>
        <div>
          <label class="form-label">Botón 2 — URL</label>
          <input type="text" name="btn2_url" value="{{ $data['btn2_url'] ?? '#tours' }}" class="form-input">
        </div>
      </div>
    </div>

    <div class="flex items-center gap-3">
      <button type="submit" class="btn-primary">Guardar cambios →</button>
      <a href="{{ url('/') }}" target="_blank" class="btn-ghost">Ver sitio ↗</a>
    </div>
  </form>
</div>
@endsection
