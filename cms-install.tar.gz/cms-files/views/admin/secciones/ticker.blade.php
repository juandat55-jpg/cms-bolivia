@extends('layouts.admin')
@section('title','Ticker / Banner')
@section('breadcrumb','Secciones → Ticker')
@section('content')
<div class="max-w-2xl">
<form method="POST" action="{{ route('admin.secciones.ticker.save') }}" class="space-y-6"
  x-data="{items: {{ json_encode(array_filter(explode('|', $data['items'] ?? 'Salar de Uyuni|Lago Titicaca'))) }}}">
@csrf
<div class="card space-y-4">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Elementos del ticker</h2>
  <p class="text-xs text-slate-500">Estos textos se muestran en el banner animado debajo del hero.</p>
  <template x-for="(item,i) in items" :key="i">
    <div class="flex gap-2 items-center">
      <input type="text" :name="`items[]`" x-model="items[i]" class="form-input flex-1" placeholder="Ej: Salar de Uyuni">
      <button type="button" @click="items.splice(i,1)"
        class="w-8 h-8 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg flex items-center justify-center flex-shrink-0">✕</button>
    </div>
  </template>
  <button type="button" @click="items.push('')"
    class="text-sm text-teal-400 hover:text-teal-300 flex items-center gap-2">
    + Agregar elemento
  </button>
</div>
{{-- Preview --}}
<div class="card">
  <label class="form-label">Vista previa</label>
  <div class="bg-amber-500/20 rounded-lg p-3 overflow-hidden">
    <div class="text-amber-300 text-sm font-bold tracking-wider truncate" x-text="items.join(' · ')"></div>
  </div>
</div>
<button type="submit" class="btn-primary">Guardar ticker →</button>
</form>
</div>
@endsection
