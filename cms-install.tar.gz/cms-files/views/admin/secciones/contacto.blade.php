{{-- contacto.blade.php --}}
@extends('layouts.admin')
@section('title','Contacto')
@section('breadcrumb','Secciones → Contacto')
@section('content')
<div class="max-w-3xl">
<form method="POST" action="{{ route('admin.secciones.contacto.save') }}" class="space-y-6">
@csrf
<div class="card space-y-5">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Encabezado</h2>
  <div><label class="form-label">Título sección</label><input type="text" name="titulo" value="{{ $data['titulo'] ?? '' }}" class="form-input"></div>
  <div><label class="form-label">Subtítulo</label><input type="text" name="subtitulo" value="{{ $data['subtitulo'] ?? '' }}" class="form-input"></div>
</div>
<div class="card space-y-5">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Datos de contacto</h2>
  <div class="grid grid-cols-2 gap-4">
    <div><label class="form-label">Teléfono</label><input type="text" name="telefono" value="{{ $data['telefono'] ?? '' }}" class="form-input" placeholder="+591 ..."></div>
    <div><label class="form-label">WhatsApp (solo números)</label><input type="text" name="whatsapp" value="{{ $data['whatsapp'] ?? '' }}" class="form-input" placeholder="591..."></div>
    <div><label class="form-label">Email</label><input type="email" name="email" value="{{ $data['email'] ?? '' }}" class="form-input"></div>
    <div><label class="form-label">Dirección / Oficina</label><input type="text" name="direccion" value="{{ $data['direccion'] ?? '' }}" class="form-input"></div>
  </div>
</div>
<div class="card space-y-5">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Redes sociales</h2>
  <div class="grid grid-cols-3 gap-4">
    <div><label class="form-label">Instagram URL</label><input type="text" name="instagram" value="{{ $data['instagram'] ?? '' }}" class="form-input" placeholder="https://instagram.com/..."></div>
    <div><label class="form-label">Facebook URL</label><input type="text" name="facebook" value="{{ $data['facebook'] ?? '' }}" class="form-input" placeholder="https://facebook.com/..."></div>
    <div><label class="form-label">TikTok URL</label><input type="text" name="tiktok" value="{{ $data['tiktok'] ?? '' }}" class="form-input" placeholder="https://tiktok.com/..."></div>
  </div>
</div>
<button type="submit" class="btn-primary">Guardar contacto →</button>
</form>
</div>
@endsection
