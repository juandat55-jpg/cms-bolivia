{{-- nosotros.blade.php --}}
@extends('layouts.admin')
@section('title','Nosotros')
@section('breadcrumb','Secciones → Nosotros')
@section('content')
<div class="max-w-3xl">
<form method="POST" action="{{ route('admin.secciones.nosotros.save') }}" enctype="multipart/form-data" class="space-y-6">
@csrf
<div class="card space-y-5">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Textos</h2>
  <div><label class="form-label">Título</label><input type="text" name="titulo" value="{{ $data['titulo'] ?? '' }}" class="form-input"></div>
  <div><label class="form-label">Subtítulo</label><input type="text" name="subtitulo" value="{{ $data['subtitulo'] ?? '' }}" class="form-input"></div>
  <div><label class="form-label">Texto principal</label><textarea name="texto" rows="5" class="form-input">{{ $data['texto'] ?? '' }}</textarea></div>
</div>
<div class="card space-y-4">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Estadísticas</h2>
  @foreach([[1,'stat1'],[2,'stat2'],[3,'stat3']] as [$n,$k])
  <div class="grid grid-cols-2 gap-4">
    <div><label class="form-label">Stat {{ $n }} — Número</label><input type="text" name="{{ $k }}_num" value="{{ $data[$k.'_num'] ?? '' }}" class="form-input" placeholder="Ej: 500+"></div>
    <div><label class="form-label">Stat {{ $n }} — Etiqueta</label><input type="text" name="{{ $k }}_label" value="{{ $data[$k.'_label'] ?? '' }}" class="form-input" placeholder="Ej: Viajeros"></div>
  </div>
  @endforeach
</div>
<div class="card space-y-4">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Imagen</h2>
  @if(!empty($data['imagen']))<div class="rounded-lg overflow-hidden h-32 bg-slate-700"><img src="{{ asset('storage/'.$data['imagen']) }}" class="w-full h-full object-cover"></div>@endif
  <input type="file" name="imagen" accept="image/*" class="w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-teal-500/20 file:text-teal-300 hover:file:bg-teal-500/30 cursor-pointer">
</div>
<button type="submit" class="btn-primary">Guardar cambios →</button>
</form>
</div>
@endsection
