@extends('layouts.admin')
@section('title','Configuración')
@section('breadcrumb','Sistema → Configuración')
@section('content')
<div class="max-w-3xl">
<form method="POST" action="{{ route('admin.config.save') }}" enctype="multipart/form-data" class="space-y-6">
@csrf
<div class="card space-y-5">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> Identidad del sitio</h2>
  <div><label class="form-label">Nombre del sitio</label><input type="text" name="site_name" value="{{ $data['site_name']->value ?? 'Hola Bolivia Travel' }}" class="form-input"></div>
  <div><label class="form-label">Tagline</label><input type="text" name="site_tagline" value="{{ $data['site_tagline']->value ?? '' }}" class="form-input"></div>
  <div>
    <label class="form-label">Logo</label>
    @if(isset($data['logo']) && $data['logo']->value)
      <div class="mb-3 bg-slate-900 rounded-lg p-3 inline-block"><img src="{{ asset('storage/'.$data['logo']->value) }}" class="h-12 object-contain"></div>
    @endif
    <input type="file" name="logo" accept="image/*,image/svg+xml"
      class="w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-teal-500/20 file:text-teal-300 hover:file:bg-teal-500/30 cursor-pointer">
    <p class="text-xs text-slate-500 mt-1">Acepta PNG, SVG, WebP. Tamaño recomendado: 200x60px</p>
  </div>
</div>
<div class="card space-y-5">
  <h2 class="text-sm font-bold text-white flex items-center gap-2"><span class="w-1 h-4 bg-teal-500 rounded-full"></span> SEO</h2>
  <div><label class="form-label">Meta descripción</label><textarea name="meta_descripcion" rows="3" class="form-input">{{ $data['meta_descripcion']->value ?? '' }}</textarea></div>
  <div><label class="form-label">Google Analytics ID</label><input type="text" name="google_analytics" value="{{ $data['google_analytics']->value ?? '' }}" class="form-input" placeholder="G-XXXXXXXXXX"></div>
</div>
<button type="submit" class="btn-primary">Guardar configuración →</button>
</form>
</div>
@endsection
