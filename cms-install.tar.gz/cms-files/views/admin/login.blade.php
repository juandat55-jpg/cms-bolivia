<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Acceso CMS — Hola Bolivia Travel</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-900 flex items-center justify-center p-4">

<div class="w-full max-w-sm">
  {{-- Logo --}}
  <div class="text-center mb-8">
    <div class="inline-flex items-center justify-center w-14 h-14 bg-teal-500 rounded-2xl text-slate-900 font-black text-xl mb-4">CMS</div>
    <h1 class="text-2xl font-bold text-white">Hola Bolivia Travel</h1>
    <p class="text-slate-400 text-sm mt-1">Panel de administración</p>
  </div>

  {{-- Form --}}
  <div class="bg-slate-800 border border-slate-700 rounded-2xl p-8">
    @if($errors->any())
      <div class="bg-red-500/20 border border-red-500/30 text-red-300 rounded-lg px-4 py-3 text-sm mb-6">
        {{ $errors->first() }}
      </div>
    @endif

    <form method="POST" action="{{ route('admin.login.post') }}">
      @csrf
      <div class="space-y-5">
        <div>
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Email</label>
          <input type="email" name="email" value="{{ old('email') }}" required autofocus
            class="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition"
            placeholder="admin@ejemplo.com">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Contraseña</label>
          <input type="password" name="password" required
            class="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition"
            placeholder="••••••••">
        </div>
        <div class="flex items-center gap-2">
          <input type="checkbox" name="remember" id="remember" class="rounded border-slate-600 bg-slate-900 text-teal-500">
          <label for="remember" class="text-sm text-slate-400">Recordarme</label>
        </div>
        <button type="submit"
          class="w-full bg-teal-500 hover:bg-teal-400 text-slate-900 font-bold py-3 rounded-lg text-sm transition-all">
          Ingresar →
        </button>
      </div>
    </form>
  </div>

  <p class="text-center text-xs text-slate-600 mt-6">
    AltitudeCode CMS v1.0
  </p>
</div>
</body>
</html>
