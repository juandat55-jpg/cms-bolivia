<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontendController;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\DestinosController;
use App\Http\Controllers\Admin\ToursController;
use App\Http\Controllers\Admin\GaleriaController;
use App\Http\Controllers\Admin\SeccionesController;

// ── FRONTEND PÚBLICO ──────────────────────────────────────────
Route::get('/', [FrontendController::class, 'index'])->name('home');

// ── ADMIN AUTH ────────────────────────────────────────────────
Route::prefix('admin')->name('admin.')->group(function () {

    Route::get('login',  [AuthController::class, 'loginForm'])->name('login');
    Route::post('login', [AuthController::class, 'login'])->name('login.post');
    Route::post('logout',[AuthController::class, 'logout'])->name('logout');

    // ── RUTAS PROTEGIDAS ──────────────────────────────────────
    Route::middleware('admin.auth')->group(function () {

        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        // Destinos
        Route::resource('destinos', DestinosController::class)->except(['show']);
        Route::post('destinos/{destino}/toggle', [DestinosController::class, 'toggleActivo'])->name('destinos.toggle');

        // Tours
        Route::resource('tours', ToursController::class)->except(['show']);
        Route::post('tours/{tour}/toggle', [ToursController::class, 'toggleActivo'])->name('tours.toggle');

        // Galería
        Route::get('galeria',                    [GaleriaController::class, 'index'])->name('galeria.index');
        Route::post('galeria/upload',            [GaleriaController::class, 'upload'])->name('galeria.upload');
        Route::patch('galeria/{galeria}',        [GaleriaController::class, 'update'])->name('galeria.update');
        Route::delete('galeria/{galeria}',       [GaleriaController::class, 'destroy'])->name('galeria.destroy');
        Route::post('galeria/reorder',           [GaleriaController::class, 'reorder'])->name('galeria.reorder');

        // Secciones
        Route::get('secciones/hero',             [SeccionesController::class, 'hero'])->name('secciones.hero');
        Route::post('secciones/hero',            [SeccionesController::class, 'heroSave'])->name('secciones.hero.save');
        Route::get('secciones/nosotros',         [SeccionesController::class, 'nosotros'])->name('secciones.nosotros');
        Route::post('secciones/nosotros',        [SeccionesController::class, 'nosotrosSave'])->name('secciones.nosotros.save');
        Route::get('secciones/ticker',           [SeccionesController::class, 'ticker'])->name('secciones.ticker');
        Route::post('secciones/ticker',          [SeccionesController::class, 'tickerSave'])->name('secciones.ticker.save');
        Route::get('secciones/contacto',         [SeccionesController::class, 'contacto'])->name('secciones.contacto');
        Route::post('secciones/contacto',        [SeccionesController::class, 'contactoSave'])->name('secciones.contacto.save');

        // Config
        Route::get('config',  [SeccionesController::class, 'config'])->name('config');
        Route::post('config', [SeccionesController::class, 'configSave'])->name('config.save');
    });
});
