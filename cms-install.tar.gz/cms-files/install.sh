#!/bin/bash
# ═══════════════════════════════════════════════════════
# CMS Hola Bolivia Travel — Script de instalación
# Ejecutar desde: /var/www/hola-bolivia-cms
# ═══════════════════════════════════════════════════════

set -e
BASEDIR="/var/www/hola-bolivia-cms"
cd $BASEDIR

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Instalando CMS Hola Bolivia Travel"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 1. Crear directorios de vistas
echo "→ Creando estructura de vistas..."
mkdir -p resources/views/layouts
mkdir -p resources/views/admin/secciones
mkdir -p resources/views/admin/destinos
mkdir -p resources/views/admin/tours
mkdir -p resources/views/admin/galeria
mkdir -p resources/views/frontend

# 2. Copiar archivos desde /tmp/cms-install
echo "→ Copiando archivos..."

# Migrations
cp /tmp/cms-install/migrations/create_cms_settings_table.php database/migrations/2026_04_28_154758_create_cms_settings_table.php
cp /tmp/cms-install/migrations/create_cms_sections_table.php  database/migrations/2026_04_28_154758_create_cms_sections_table.php
cp /tmp/cms-install/migrations/create_destinos_table.php      database/migrations/2026_04_28_154758_create_destinos_table.php
cp /tmp/cms-install/migrations/create_tours_table.php         database/migrations/2026_04_28_154758_create_tours_table.php
cp /tmp/cms-install/migrations/create_galeria_table.php       database/migrations/2026_04_28_154759_create_galeria_table.php
cp /tmp/cms-install/migrations/create_admin_users_table.php   database/migrations/2026_04_28_154759_create_admin_users_table.php

# Models
cp /tmp/cms-install/models/AdminUser.php    app/Models/AdminUser.php
cp /tmp/cms-install/models/Destino.php      app/Models/Destino.php
cp /tmp/cms-install/models/Tour.php         app/Models/Tour.php
cp /tmp/cms-install/models/Galeria.php      app/Models/Galeria.php
cp /tmp/cms-install/models/CmsSetting.php   app/Models/CmsSetting.php
cp /tmp/cms-install/models/CmsSection.php   app/Models/CmsSection.php

# Middleware
cp /tmp/cms-install/middleware/AdminAuth.php app/Http/Middleware/AdminAuth.php

# Controllers
mkdir -p app/Http/Controllers/Admin
cp /tmp/cms-install/controllers/AuthController.php      app/Http/Controllers/Admin/AuthController.php
cp /tmp/cms-install/controllers/DashboardController.php app/Http/Controllers/Admin/DashboardController.php
cp /tmp/cms-install/controllers/SeccionesController.php app/Http/Controllers/Admin/SeccionesController.php
cp /tmp/cms-install/controllers/DestinosController.php  app/Http/Controllers/Admin/DestinosController.php
cp /tmp/cms-install/controllers/ToursController.php     app/Http/Controllers/Admin/ToursController.php
cp /tmp/cms-install/controllers/GaleriaController.php   app/Http/Controllers/Admin/GaleriaController.php
cp /tmp/cms-install/controllers/FrontendController.php  app/Http/Controllers/FrontendController.php

# Seeder
cp /tmp/cms-install/seeders/CmsSeeder.php database/seeders/CmsSeeder.php

# Routes
cp /tmp/cms-install/routes/web.php routes/web.php

# Views
cp /tmp/cms-install/views/layouts/admin.blade.php        resources/views/layouts/admin.blade.php
cp /tmp/cms-install/views/admin/login.blade.php          resources/views/admin/login.blade.php
cp /tmp/cms-install/views/admin/dashboard.blade.php      resources/views/admin/dashboard.blade.php
cp /tmp/cms-install/views/admin/secciones/hero.blade.php          resources/views/admin/secciones/hero.blade.php
cp /tmp/cms-install/views/admin/secciones/nosotros.blade.php      resources/views/admin/secciones/nosotros.blade.php
cp /tmp/cms-install/views/admin/secciones/ticker.blade.php        resources/views/admin/secciones/ticker.blade.php
cp /tmp/cms-install/views/admin/secciones/contacto.blade.php      resources/views/admin/secciones/contacto.blade.php
cp /tmp/cms-install/views/admin/secciones/config.blade.php        resources/views/admin/secciones/config.blade.php
cp /tmp/cms-install/views/admin/destinos/index.blade.php          resources/views/admin/destinos/index.blade.php
cp /tmp/cms-install/views/admin/destinos/form.blade.php           resources/views/admin/destinos/form.blade.php
cp /tmp/cms-install/views/admin/tours/index.blade.php             resources/views/admin/tours/index.blade.php
cp /tmp/cms-install/views/admin/tours/form.blade.php              resources/views/admin/tours/form.blade.php
cp /tmp/cms-install/views/admin/galeria/index.blade.php           resources/views/admin/galeria/index.blade.php

echo "✓ Archivos copiados"

# 3. Storage link
echo "→ Creando symlink de storage..."
php artisan storage:link 2>/dev/null || true

# 4. Migraciones
echo "→ Ejecutando migraciones..."
php artisan migrate --force

# 5. Seeder
echo "→ Cargando datos iniciales..."
php artisan db:seed --class=CmsSeeder --force

# 6. Cache
echo "→ Optimizando..."
php artisan config:clear
php artisan cache:clear
php artisan view:clear
php artisan route:clear

# 7. Permisos
chmod -R 775 storage bootstrap/cache

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅ CMS instalado correctamente"
echo ""
echo "  URL Panel: https://pruebas.altitudecodelab.com/admin"
echo "  Email:     admin@holaboliviatravel.com"
echo "  Password:  Bolivia2026!"
echo ""
echo "  ⚠️  Cambia la contraseña después del primer login"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
