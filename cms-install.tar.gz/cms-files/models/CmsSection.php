<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class CmsSection extends Model {
    protected $fillable = ['seccion','campo','valor','tipo'];

    public static function get(string $seccion, string $campo, $default = null) {
        return Cache::remember("cms_sec_{$seccion}_{$campo}", 3600, function() use ($seccion, $campo, $default) {
            $s = static::where('seccion',$seccion)->where('campo',$campo)->first();
            return $s ? $s->valor : $default;
        });
    }

    public static function set(string $seccion, string $campo, $valor) {
        Cache::forget("cms_sec_{$seccion}_{$campo}");
        return static::updateOrCreate(
            ['seccion'=>$seccion,'campo'=>$campo],
            ['valor'=>$valor]
        );
    }

    public static function seccion(string $seccion): array {
        return static::where('seccion',$seccion)->pluck('valor','campo')->toArray();
    }
}
