<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Galeria extends Model {
    protected $table = 'galeria';
    protected $fillable = ['titulo','archivo','tipo','seccion','referencia_id','descripcion','alt','activo','orden'];
    protected $casts = ['activo'=>'boolean'];

    public function getUrlAttribute() {
        return asset('storage/'.$this->archivo);
    }
    public function scopeActivos($q) { return $q->where('activo',true)->orderBy('orden'); }
    public function scopeSeccion($q,$s) { return $q->where('seccion',$s); }
}
