<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Tour extends Model {
    protected $fillable = ['nombre','slug','categoria','descripcion_corta','descripcion','imagen','duracion','precio_desde','dificultad','max_personas','incluye','no_incluye','destacado','activo','orden'];
    protected $casts = ['incluye'=>'array','no_incluye'=>'array','destacado'=>'boolean','activo'=>'boolean'];

    protected static function boot() {
        parent::boot();
        static::creating(function($m) {
            if(empty($m->slug)) $m->slug = Str::slug($m->nombre);
        });
    }
    public function scopeActivos($q) { return $q->where('activo',true)->orderBy('orden'); }
    public function getImagenUrlAttribute() {
        return $this->imagen ? asset('storage/'.$this->imagen) : asset('img/placeholder.jpg');
    }
}
