<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class CmsSetting extends Model {
    protected $fillable = ['key','value','type','group','label'];

    public static function get(string $key, $default = null) {
        return Cache::remember("cms_{$key}", 3600, function() use ($key, $default) {
            $s = static::where('key',$key)->first();
            return $s ? $s->value : $default;
        });
    }

    public static function set(string $key, $value) {
        Cache::forget("cms_{$key}");
        return static::updateOrCreate(['key'=>$key],['value'=>$value]);
    }

    public static function grupo(string $grupo): array {
        return static::where('group',$grupo)->pluck('value','key')->toArray();
    }
}
