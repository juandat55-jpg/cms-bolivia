<?php
// ═══════════════════════════════════════════
// app/Models/AdminUser.php
// ═══════════════════════════════════════════
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class AdminUser extends Authenticatable {
    use Notifiable;
    protected $guard = 'admin';
    protected $fillable = ['nombre','email','password','rol','avatar','ultimo_acceso','activo'];
    protected $hidden = ['password','remember_token'];
    protected $casts = ['ultimo_acceso' => 'datetime', 'activo' => 'boolean'];
}
