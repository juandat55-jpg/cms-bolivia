<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Destino extends Model {
    protected $fillable = ['nombre','slug','ubicacion','descripcion_corta','descripcion','imagen','imagen_banner','duracion','precio_desde','destacado','activo','orden'];
    protected $casts = ['destacado'=>'boolean','activo'=>'boolean'];

    protected static function boot() {
        parent::boot();
        static::creating(function($m) {
            if(empty($m->slug)) $m->slug = Str::slug($m->nombre);
        });
    }
    public function scopeActivos($q) { return $q->where('activo',true)->orderBy('orden'); }
    public function getImagenUrlAttribute() {
        return $this->imagen ? asset('storage/'.$this->imagen) : asset('img/placeholder.jpg');
    }
}
