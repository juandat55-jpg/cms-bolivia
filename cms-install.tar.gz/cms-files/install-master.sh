#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# INSTALADOR MAESTRO — CMS Hola Bolivia Travel
# Uso: bash <(curl -s URL) o copiar y pegar en el servidor
# ═══════════════════════════════════════════════════════════════

set -e
BASE="/var/www/hola-bolivia-cms"
cd $BASE

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  CMS Hola Bolivia Travel — Instalando"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── 1. CREAR DIRECTORIOS ─────────────────────────────────────
mkdir -p resources/views/{layouts,frontend}
mkdir -p resources/views/admin/{secciones,destinos,tours,galeria}
mkdir -p app/Http/{Controllers/Admin,Middleware}
mkdir -p app/Models
mkdir -p database/seeders

# ── 2. CONFIGURAR AUTH GUARD ─────────────────────────────────
python3 << 'PYEOF'
import re

f = open('config/auth.php', 'r')
c = f.read()
f.close()

if "'admin'" not in c:
    c = c.replace(
        "'guards' => [",
        """'guards' => [
        'admin' => [
            'driver' => 'session',
            'provider' => 'admin_users',
        ],"""
    )
    c = c.replace(
        "'providers' => [",
        """'providers' => [
        'admin_users' => [
            'driver' => 'eloquent',
            'model' => App\\Models\\AdminUser::class,
        ],"""
    )
    f = open('config/auth.php', 'w')
    f.write(c)
    f.close()
    print("✓ Auth guard 'admin' configurado")
else:
    print("✓ Auth guard ya configurado")
PYEOF

# ── 3. REGISTRAR MIDDLEWARE EN bootstrap/app.php ─────────────
python3 << 'PYEOF'
f = open('bootstrap/app.php', 'r')
c = f.read()
f.close()

if 'admin.auth' not in c:
    c = c.replace(
        '->withMiddleware(function (Middleware $middleware) {',
        """->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'admin.auth' => \\App\\Http\\Middleware\\AdminAuth::class,
        ]);"""
    )
    f = open('bootstrap/app.php', 'w')
    f.write(c)
    f.close()
    print("✓ Middleware registrado")
else:
    print("✓ Middleware ya registrado")
PYEOF

# ── 4. COPIAR ARCHIVOS DEL CMS ───────────────────────────────
SRC="/tmp/cms-install"

copy_file() {
    local src="$1" dst="$2"
    if [ -f "$SRC/$src" ]; then
        cp "$SRC/$src" "$BASE/$dst"
        echo "  ✓ $dst"
    else
        echo "  ✗ FALTA: $src"
    fi
}

echo "→ Copiando migraciones..."
STAMP="2026_04_28_1547"
copy_file "migrations/create_cms_settings_table.php"  "database/migrations/${STAMP}58_create_cms_settings_table.php"
copy_file "migrations/create_cms_sections_table.php"  "database/migrations/${STAMP}58_create_cms_sections_table.php"
copy_file "migrations/create_destinos_table.php"      "database/migrations/${STAMP}58_create_destinos_table.php"
copy_file "migrations/create_tours_table.php"         "database/migrations/${STAMP}58_create_tours_table.php"
copy_file "migrations/create_galeria_table.php"       "database/migrations/${STAMP}59_create_galeria_table.php"
copy_file "migrations/create_admin_users_table.php"   "database/migrations/${STAMP}59_create_admin_users_table.php"

echo "→ Copiando modelos..."
copy_file "models/AdminUser.php"   "app/Models/AdminUser.php"
copy_file "models/Destino.php"     "app/Models/Destino.php"
copy_file "models/Tour.php"        "app/Models/Tour.php"
copy_file "models/Galeria.php"     "app/Models/Galeria.php"
copy_file "models/CmsSetting.php"  "app/Models/CmsSetting.php"
copy_file "models/CmsSection.php"  "app/Models/CmsSection.php"

echo "→ Copiando middleware y controllers..."
copy_file "middleware/AdminAuth.php"              "app/Http/Middleware/AdminAuth.php"
copy_file "controllers/AuthController.php"        "app/Http/Controllers/Admin/AuthController.php"
copy_file "controllers/DashboardController.php"   "app/Http/Controllers/Admin/DashboardController.php"
copy_file "controllers/SeccionesController.php"   "app/Http/Controllers/Admin/SeccionesController.php"
copy_file "controllers/DestinosController.php"    "app/Http/Controllers/Admin/DestinosController.php"
copy_file "controllers/ToursController.php"       "app/Http/Controllers/Admin/ToursController.php"
copy_file "controllers/GaleriaController.php"     "app/Http/Controllers/Admin/GaleriaController.php"
copy_file "controllers/FrontendController.php"    "app/Http/Controllers/FrontendController.php"

echo "→ Copiando seeder y routes..."
copy_file "seeders/CmsSeeder.php"  "database/seeders/CmsSeeder.php"
copy_file "routes/web.php"         "routes/web.php"

echo "→ Copiando vistas..."
copy_file "views/layouts/admin.blade.php"               "resources/views/layouts/admin.blade.php"
copy_file "views/admin/login.blade.php"                 "resources/views/admin/login.blade.php"
copy_file "views/admin/dashboard.blade.php"             "resources/views/admin/dashboard.blade.php"
copy_file "views/admin/secciones/hero.blade.php"        "resources/views/admin/secciones/hero.blade.php"
copy_file "views/admin/secciones/nosotros.blade.php"    "resources/views/admin/secciones/nosotros.blade.php"
copy_file "views/admin/secciones/ticker.blade.php"      "resources/views/admin/secciones/ticker.blade.php"
copy_file "views/admin/secciones/contacto.blade.php"    "resources/views/admin/secciones/contacto.blade.php"
copy_file "views/admin/secciones/config.blade.php"      "resources/views/admin/secciones/config.blade.php"
copy_file "views/admin/destinos/index.blade.php"        "resources/views/admin/destinos/index.blade.php"
copy_file "views/admin/destinos/form.blade.php"         "resources/views/admin/destinos/form.blade.php"
copy_file "views/admin/tours/index.blade.php"           "resources/views/admin/tours/index.blade.php"
copy_file "views/admin/tours/form.blade.php"            "resources/views/admin/tours/form.blade.php"
copy_file "views/admin/galeria/index.blade.php"         "resources/views/admin/galeria/index.blade.php"

# ── 5. FRONTEND PLACEHOLDER ──────────────────────────────────
if [ ! -f "resources/views/frontend/index.blade.php" ]; then
cat > resources/views/frontend/index.blade.php << 'EOF'
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>Hola Bolivia Travel</title></head>
<body>
<p>Sitio en construcción — <a href="/admin">Ir al panel →</a></p>
</body>
</html>
EOF
echo "  ✓ Frontend placeholder creado"
fi

# ── 6. STORAGE LINK ──────────────────────────────────────────
echo "→ Creando storage link..."
php artisan storage:link 2>/dev/null || true

# ── 7. MIGRACIONES ───────────────────────────────────────────
echo "→ Ejecutando migraciones..."
php artisan migrate --force

# ── 8. SEEDER ────────────────────────────────────────────────
echo "→ Cargando datos iniciales..."
php artisan db:seed --class=CmsSeeder --force

# ── 9. LIMPIAR CACHE ─────────────────────────────────────────
echo "→ Limpiando cache..."
php artisan config:clear
php artisan cache:clear
php artisan view:clear
php artisan route:clear

# ── 10. PERMISOS ─────────────────────────────────────────────
chmod -R 775 storage bootstrap/cache

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅ CMS instalado correctamente"
echo ""
echo "  🌐 Panel:    https://pruebas.altitudecodelab.com/admin"
echo "  📧 Email:    admin@holaboliviatravel.com"
echo "  🔑 Password: Bolivia2026!"
echo ""
echo "  ⚠️  Cambia la contraseña después del primer login"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
