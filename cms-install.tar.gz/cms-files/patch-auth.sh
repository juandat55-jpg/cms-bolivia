#!/bin/bash
# Patch auth.php para agregar guard 'admin'
cd /var/www/hola-bolivia-cms

php artisan tinker --execute="
\$authFile = config_path('auth.php');
\$content = file_get_contents(\$authFile);

// Agregar guard admin
if (strpos(\$content, \"'admin'\") === false) {
    \$content = str_replace(
        \"'guards' => [\",
        \"'guards' => [\\n        'admin' => [\\n            'driver' => 'session',\\n            'provider' => 'admin_users',\\n        ],\",
        \$content
    );
    // Agregar provider admin_users
    \$content = str_replace(
        \"'providers' => [\",
        \"'providers' => [\\n        'admin_users' => [\\n            'driver' => 'eloquent',\\n            'model' => App\\\\Models\\\\AdminUser::class,\\n        ],\",
        \$content
    );
    file_put_contents(\$authFile, \$content);
    echo 'Auth config actualizado';
} else {
    echo 'Auth config ya tiene guard admin';
}
" 2>/dev/null || echo "Usar método manual"
