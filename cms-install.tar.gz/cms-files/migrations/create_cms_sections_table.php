<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('cms_sections', function (Blueprint $table) {
            $table->id();
            $table->string('seccion'); // hero, nosotros, contacto, ticker
            $table->string('campo');   // titulo, subtitulo, texto, etc
            $table->longText('valor')->nullable();
            $table->string('tipo')->default('text'); // text, textarea, image, video, color
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('cms_sections'); }
};
