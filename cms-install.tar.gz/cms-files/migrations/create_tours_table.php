<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tours', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->string('slug')->unique();
            $table->string('categoria')->nullable(); // aventura, cultural, naturaleza
            $table->text('descripcion_corta')->nullable();
            $table->longText('descripcion')->nullable();
            $table->string('imagen')->nullable();
            $table->string('duracion')->nullable();
            $table->string('precio_desde')->nullable();
            $table->string('dificultad')->nullable(); // fácil, moderado, difícil
            $table->integer('max_personas')->nullable();
            $table->json('incluye')->nullable();
            $table->json('no_incluye')->nullable();
            $table->boolean('destacado')->default(false);
            $table->boolean('activo')->default(true);
            $table->integer('orden')->default(0);
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tours'); }
};
