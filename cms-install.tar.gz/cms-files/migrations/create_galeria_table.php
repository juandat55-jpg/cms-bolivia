<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('galeria', function (Blueprint $table) {
            $table->id();
            $table->string('titulo')->nullable();
            $table->string('archivo');
            $table->string('tipo')->default('imagen'); // imagen, video
            $table->string('seccion')->default('galeria'); // galeria, hero, destino, tour
            $table->unsignedBigInteger('referencia_id')->nullable(); // id de destino/tour
            $table->text('descripcion')->nullable();
            $table->string('alt')->nullable();
            $table->boolean('activo')->default(true);
            $table->integer('orden')->default(0);
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('galeria'); }
};
